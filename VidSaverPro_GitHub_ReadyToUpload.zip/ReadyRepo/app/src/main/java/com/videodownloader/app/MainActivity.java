package com.videodownloader.app;

import android.Manifest;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    // UI References
    private EditText etUrl;
    private ImageView ivPaste, ivClear, ivThumbnail;
    private TextView tvVideoTitle, tvDuration, tvLoadingText;
    private TextView tvToggleVideo, tvToggleAudio;
    private TextView tvBest, tv1080p, tv720p, tv480p;
    private TextView tvProgressStatus, tvProgressPercent;
    private TextView tvError;
    private CardView cardResult, cardLoading, cardProgress, cardError;
    private ProgressBar progressBar;
    private LinearLayout llQuality;

    // State
    private String selectedQuality = "1080";
    private boolean isVideoMode = true;
    private String currentVideoUrl = "";
    private String currentDownloadUrl = "";
    private VideoInfo currentVideoInfo;
    private long downloadId = -1;

    // HTTP
    private OkHttpClient httpClient;
    private Handler mainHandler;

    // Constants
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final String PREF_NAME = "VidSaverHistory";
    private static final String API_BASE = "https://api.cobalt.tools/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupHttpClient();
        setupClickListeners();
        handleShareIntent();
    }

    private void initViews() {
        etUrl = findViewById(R.id.etUrl);
        ivPaste = findViewById(R.id.ivPaste);
        ivClear = findViewById(R.id.ivClear);
        ivThumbnail = findViewById(R.id.ivThumbnail);
        tvVideoTitle = findViewById(R.id.tvVideoTitle);
        tvDuration = findViewById(R.id.tvDuration);
        tvLoadingText = findViewById(R.id.tvLoadingText);
        tvToggleVideo = findViewById(R.id.tvToggleVideo);
        tvToggleAudio = findViewById(R.id.tvToggleAudio);
        tvBest = findViewById(R.id.tvBest);
        tv1080p = findViewById(R.id.tv1080p);
        tv720p = findViewById(R.id.tv720p);
        tv480p = findViewById(R.id.tv480p);
        tvProgressStatus = findViewById(R.id.tvProgressStatus);
        tvProgressPercent = findViewById(R.id.tvProgressPercent);
        tvError = findViewById(R.id.tvError);
        cardResult = findViewById(R.id.cardResult);
        cardLoading = findViewById(R.id.cardLoading);
        cardProgress = findViewById(R.id.cardProgress);
        cardError = findViewById(R.id.cardError);
        progressBar = findViewById(R.id.progressBar);
        llQuality = findViewById(R.id.llQuality);
        mainHandler = new Handler(Looper.getMainLooper());
    }

    private void setupHttpClient() {
        httpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    private void setupClickListeners() {
        // Paste button
        ivPaste.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null && clipboard.hasPrimaryClip()) {
                ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
                String text = item.getText().toString().trim();
                etUrl.setText(text);
                etUrl.setSelection(text.length());
                if (isValidUrl(text)) {
                    analyzeUrl(text);
                }
            } else {
                Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show();
            }
        });

        // Clear button
        ivClear.setOnClickListener(v -> {
            etUrl.setText("");
            hideAllCards();
        });

        // Analyze button
        findViewById(R.id.btnAnalyze).setOnClickListener(v -> {
            String url = etUrl.getText().toString().trim();
            if (TextUtils.isEmpty(url)) {
                showError("Please paste a video URL first");
                return;
            }
            if (!isValidUrl(url)) {
                showError("Invalid URL. Please enter a valid video link.");
                return;
            }
            analyzeUrl(url);
        });

        // VIDEO/AUDIO toggle
        tvToggleVideo.setOnClickListener(v -> setVideoMode(true));
        tvToggleAudio.setOnClickListener(v -> setVideoMode(false));

        // Quality buttons
        tvBest.setOnClickListener(v -> selectQuality("best"));
        tv1080p.setOnClickListener(v -> selectQuality("1080"));
        tv720p.setOnClickListener(v -> selectQuality("720"));
        tv480p.setOnClickListener(v -> selectQuality("480"));

        // Download button
        findViewById(R.id.btnDownload).setOnClickListener(v -> startDownload());

        // Platform cards - tap to fill URL hint
        findViewById(R.id.cardYoutube).setOnClickListener(v -> {
            etUrl.setHint("https://youtube.com/watch?v=...");
            etUrl.requestFocus();
            Toast.makeText(this, "Paste YouTube link", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.cardInstagram).setOnClickListener(v -> {
            etUrl.setHint("https://instagram.com/reel/...");
            etUrl.requestFocus();
            Toast.makeText(this, "Paste Instagram link", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.cardFacebook).setOnClickListener(v -> {
            etUrl.setHint("https://facebook.com/watch?v=...");
            etUrl.requestFocus();
            Toast.makeText(this, "Paste Facebook link", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.cardTwitter).setOnClickListener(v -> {
            etUrl.setHint("https://twitter.com/i/status/...");
            etUrl.requestFocus();
            Toast.makeText(this, "Paste Twitter/X link", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.cardTiktok).setOnClickListener(v -> {
            etUrl.setHint("https://tiktok.com/@user/video/...");
            etUrl.requestFocus();
            Toast.makeText(this, "Paste TikTok link", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.cardMore).setOnClickListener(v ->
            Toast.makeText(this, "Supports YouTube, Instagram, Facebook, Twitter, TikTok, Dailymotion, Vimeo, Reddit, Pinterest & 1000+ more!", Toast.LENGTH_LONG).show()
        );

        // History
        findViewById(R.id.tvHistory).setOnClickListener(v -> {
            Intent i = new Intent(this, HistoryActivity.class);
            startActivity(i);
        });

        // Settings
        findViewById(R.id.tvSettings).setOnClickListener(v -> {
            Intent i = new Intent(this, SettingsActivity.class);
            startActivity(i);
        });
    }

    // ============================================================
    //  URL ANALYSIS  (uses cobalt.tools - free, open-source API)
    // ============================================================
    private void analyzeUrl(String url) {
        currentVideoUrl = url;
        hideAllCards();
        showLoading("Analyzing link...");

        // Detect platform
        String platform = detectPlatform(url);
        tvLoadingText.setText("Analyzing " + platform + " link...");

        // Build cobalt.tools request
        String jsonBody = "{\"url\":\"" + url + "\",\"vQuality\":\"" + selectedQuality + "\","
                + "\"filenameStyle\":\"pretty\",\"downloadMode\":\""
                + (isVideoMode ? "auto" : "audio") + "\"}";

        okhttp3.RequestBody body = okhttp3.RequestBody.create(
                jsonBody,
                okhttp3.MediaType.parse("application/json; charset=utf-8")
        );

        Request request = new Request.Builder()
                .url(API_BASE)
                .post(body)
                .addHeader("Accept", "application/json")
                .addHeader("Content-Type", "application/json")
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                mainHandler.post(() -> {
                    hideAllCards();
                    showError("Network error: " + e.getMessage() + "\nCheck your internet connection.");
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseBody = response.body() != null ? response.body().string() : "";
                mainHandler.post(() -> {
                    hideAllCards();
                    try {
                        JsonObject json = new Gson().fromJson(responseBody, JsonObject.class);
                        String status = json.has("status") ? json.get("status").getAsString() : "";

                        if (status.equals("stream") || status.equals("redirect") || status.equals("tunnel")) {
                            // Direct download URL available
                            currentDownloadUrl = json.has("url") ? json.get("url").getAsString() : "";
                            String filename = json.has("filename") ? json.get("filename").getAsString() : "video";

                            // Show result card with info
                            VideoInfo info = new VideoInfo();
                            info.title = filename;
                            info.duration = "";
                            info.platform = detectPlatform(currentVideoUrl);
                            info.thumbnailUrl = extractYoutubeThumbnail(currentVideoUrl);
                            showResult(info, currentDownloadUrl);

                        } else if (status.equals("picker")) {
                            // Multiple streams (e.g. Twitter videos)
                            JsonArray pickerArray = json.getAsJsonArray("picker");
                            if (pickerArray != null && pickerArray.size() > 0) {
                                currentDownloadUrl = pickerArray.get(0).getAsJsonObject()
                                        .get("url").getAsString();
                                VideoInfo info = new VideoInfo();
                                info.title = "Video from " + detectPlatform(currentVideoUrl);
                                info.platform = detectPlatform(currentVideoUrl);
                                info.thumbnailUrl = extractYoutubeThumbnail(currentVideoUrl);
                                showResult(info, currentDownloadUrl);
                            }
                        } else if (status.equals("error")) {
                            String errorCode = json.has("error") ? 
                                json.get("error").getAsJsonObject().get("code").getAsString() : "unknown";
                            showError("ERROR: " + errorCode + "\n\nTip: Make sure the link is public and not age-restricted.");
                        } else {
                            showError("Unexpected response: " + status + "\n" + responseBody.substring(0, Math.min(200, responseBody.length())));
                        }
                    } catch (Exception e) {
                        showError("Parse error: " + e.getMessage() + "\nResponse: " + responseBody.substring(0, Math.min(300, responseBody.length())));
                    }
                });
            }
        });
    }

    // ============================================================
    //  DOWNLOAD
    // ============================================================
    private void startDownload() {
        if (TextUtils.isEmpty(currentDownloadUrl)) {
            Toast.makeText(this, "No download URL available", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check permission
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_CODE);
                return;
            }
        }

        cardResult.setVisibility(View.GONE);
        cardProgress.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);
        tvProgressPercent.setText("0%");
        tvProgressStatus.setText("Downloading...");

        String ext = isVideoMode ? ".mp4" : ".mp3";
        String fileName = "VidSaver_" + System.currentTimeMillis() + ext;

        DownloadManager.Request dmRequest = new DownloadManager.Request(Uri.parse(currentDownloadUrl));
        dmRequest.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        dmRequest.setDestinationInExternalPublicDir(
                isVideoMode ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_MUSIC,
                fileName);
        dmRequest.setTitle("VidSaver - Downloading...");
        dmRequest.setDescription(tvVideoTitle.getText().toString());
        dmRequest.addRequestHeader("User-Agent", "Mozilla/5.0");
        dmRequest.allowScanningByMediaScanner();

        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (dm != null) {
            downloadId = dm.enqueue(dmRequest);
            saveToHistory(tvVideoTitle.getText().toString(), currentVideoUrl, fileName);
            trackDownloadProgress(dm);
        }
    }

    private void trackDownloadProgress(DownloadManager dm) {
        Runnable progressRunnable = new Runnable() {
            @Override
            public void run() {
                if (downloadId == -1) return;
                DownloadManager.Query query = new DownloadManager.Query();
                query.setFilterById(downloadId);
                Cursor cursor = dm.query(query);
                if (cursor != null && cursor.moveToFirst()) {
                    int statusCol = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS);
                    int status = cursor.getInt(statusCol);

                    if (status == DownloadManager.STATUS_RUNNING) {
                        int bytesCol = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
                        int totalCol = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
                        long downloaded = cursor.getLong(bytesCol);
                        long total = cursor.getLong(totalCol);
                        if (total > 0) {
                            int progress = (int) (downloaded * 100 / total);
                            mainHandler.post(() -> {
                                progressBar.setProgress(progress);
                                tvProgressPercent.setText(progress + "%");
                                tvProgressStatus.setText(formatBytes(downloaded) + " / " + formatBytes(total));
                            });
                        }
                        mainHandler.postDelayed(this, 500);
                    } else if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        mainHandler.post(() -> {
                            progressBar.setProgress(100);
                            tvProgressPercent.setText("100%");
                            tvProgressStatus.setText("✓ Download Complete!");
                            Toast.makeText(MainActivity.this,
                                    "✓ Saved to " + (isVideoMode ? "Movies" : "Music") + " folder",
                                    Toast.LENGTH_LONG).show();
                        });
                    } else if (status == DownloadManager.STATUS_FAILED) {
                        int reasonCol = cursor.getColumnIndex(DownloadManager.COLUMN_REASON);
                        int reason = cursor.getInt(reasonCol);
                        mainHandler.post(() -> {
                            cardProgress.setVisibility(View.GONE);
                            showError("Download failed! Reason code: " + reason
                                    + "\n\nThe server blocked direct download. Try opening in browser.");
                        });
                    }
                    cursor.close();
                }
            }
        };
        mainHandler.postDelayed(progressRunnable, 500);
    }

    // ============================================================
    //  UI HELPERS
    // ============================================================
    private void showResult(VideoInfo info, String downloadUrl) {
        currentVideoInfo = info;
        currentDownloadUrl = downloadUrl;

        tvVideoTitle.setText(info.title);
        tvDuration.setText(TextUtils.isEmpty(info.duration) ? "Platform: " + info.platform : "Duration: " + info.duration);

        if (!TextUtils.isEmpty(info.thumbnailUrl)) {
            Glide.with(this).load(info.thumbnailUrl).centerCrop().into(ivThumbnail);
        } else {
            ivThumbnail.setImageResource(android.R.color.darker_gray);
        }

        cardResult.setVisibility(View.VISIBLE);
        cardResult.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));
    }

    private void showLoading(String message) {
        tvLoadingText.setText(message);
        cardLoading.setVisibility(View.VISIBLE);
    }

    private void showError(String message) {
        tvError.setText(message);
        cardError.setVisibility(View.VISIBLE);
    }

    private void hideAllCards() {
        cardResult.setVisibility(View.GONE);
        cardLoading.setVisibility(View.GONE);
        cardProgress.setVisibility(View.GONE);
        cardError.setVisibility(View.GONE);
    }

    private void setVideoMode(boolean video) {
        isVideoMode = video;
        if (video) {
            tvToggleVideo.setBackgroundResource(R.drawable.toggle_active_bg);
            tvToggleVideo.setTextColor(getColor(R.color.bg_dark));
            tvToggleAudio.setBackgroundResource(0);
            tvToggleAudio.setTextColor(getColor(R.color.text_secondary));
            llQuality.setVisibility(View.VISIBLE);
        } else {
            tvToggleAudio.setBackgroundResource(R.drawable.toggle_active_bg);
            tvToggleAudio.setTextColor(getColor(R.color.bg_dark));
            tvToggleVideo.setBackgroundResource(0);
            tvToggleVideo.setTextColor(getColor(R.color.text_secondary));
            llQuality.setVisibility(View.GONE);
        }
    }

    private void selectQuality(String q) {
        selectedQuality = q;
        resetQualityButtons();
        switch (q) {
            case "best": setActiveQuality(tvBest); break;
            case "1080": setActiveQuality(tv1080p); break;
            case "720":  setActiveQuality(tv720p); break;
            case "480":  setActiveQuality(tv480p); break;
        }
    }

    private void resetQualityButtons() {
        for (TextView tv : new TextView[]{tvBest, tv1080p, tv720p, tv480p}) {
            tv.setBackgroundResource(R.drawable.quality_btn_bg);
            tv.setTextColor(getColor(R.color.text_secondary));
        }
    }

    private void setActiveQuality(TextView tv) {
        tv.setBackgroundResource(R.drawable.quality_btn_active_bg);
        tv.setTextColor(getColor(R.color.bg_dark));
    }

    // ============================================================
    //  UTILITIES
    // ============================================================
    private boolean isValidUrl(String url) {
        return url.startsWith("http://") || url.startsWith("https://");
    }

    private String detectPlatform(String url) {
        if (url.contains("youtube.com") || url.contains("youtu.be")) return "YouTube";
        if (url.contains("instagram.com")) return "Instagram";
        if (url.contains("facebook.com") || url.contains("fb.watch")) return "Facebook";
        if (url.contains("twitter.com") || url.contains("x.com")) return "Twitter/X";
        if (url.contains("tiktok.com")) return "TikTok";
        if (url.contains("vimeo.com")) return "Vimeo";
        if (url.contains("dailymotion.com")) return "Dailymotion";
        if (url.contains("reddit.com")) return "Reddit";
        if (url.contains("pinterest.com")) return "Pinterest";
        if (url.contains("twitch.tv")) return "Twitch";
        return "Video";
    }

    private String extractYoutubeThumbnail(String url) {
        if (url.contains("youtube.com") || url.contains("youtu.be")) {
            String videoId = extractYoutubeId(url);
            if (videoId != null) {
                return "https://img.youtube.com/vi/" + videoId + "/hqdefault.jpg";
            }
        }
        return "";
    }

    private String extractYoutubeId(String url) {
        String[] patterns = {
            "(?:v=|youtu\\.be/)([a-zA-Z0-9_-]{11})"
        };
        for (String p : patterns) {
            Pattern pattern = Pattern.compile(p);
            Matcher matcher = pattern.matcher(url);
            if (matcher.find()) return matcher.group(1);
        }
        return null;
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        return String.format("%.1f MB", bytes / (1024.0 * 1024));
    }

    private void saveToHistory(String title, String url, String filename) {
        SharedPreferences prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        String historyJson = prefs.getString("history", "[]");
        try {
            com.google.gson.JsonArray arr = new Gson().fromJson(historyJson, com.google.gson.JsonArray.class);
            JsonObject item = new JsonObject();
            item.addProperty("title", title);
            item.addProperty("url", url);
            item.addProperty("filename", filename);
            item.addProperty("time", System.currentTimeMillis());
            arr.add(item);
            prefs.edit().putString("history", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void handleShareIntent() {
        Intent intent = getIntent();
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (!TextUtils.isEmpty(sharedText) && isValidUrl(sharedText.trim())) {
                etUrl.setText(sharedText.trim());
                analyzeUrl(sharedText.trim());
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == PERMISSION_REQUEST_CODE && results.length > 0
                && results[0] == PackageManager.PERMISSION_GRANTED) {
            startDownload();
        } else {
            Toast.makeText(this, "Storage permission needed to save files", Toast.LENGTH_SHORT).show();
        }
    }

    // Simple VideoInfo POJO
    static class VideoInfo {
        String title, duration, thumbnailUrl, platform, downloadUrl;
    }
}
